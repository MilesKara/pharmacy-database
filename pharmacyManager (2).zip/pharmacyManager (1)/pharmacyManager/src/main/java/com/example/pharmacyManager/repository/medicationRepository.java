package com.example.pharmacyManager.repository;

import com.example.pharmacyManager.entities.medication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface medicationRepository extends JpaRepository<medication, Integer> {
    medication findByName(String name);
    List<medication> findByManufacturerId(Integer manufacturerId);
}