package com.example.pharmacyManager.controller;
import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*;  
import org.springframework.http.ResponseEntity;
import com.example.pharmacyManager.entities.prescription; 
@RestController
@RequestMapping("/api/prescriptions")

public class prescriptionController {
    @Autowired
    private com.example.pharmacyManager.repository.prescriptionRepository prescriptionRepository;

    @GetMapping
    public List<prescription> getAllPrescriptions() {
        return prescriptionRepository.findAll();
    }

    @PostMapping
    public prescription createPrescription(@RequestBody prescription prescription) {
        return prescriptionRepository.save(prescription);
    }

    @GetMapping("/{id}")
    public ResponseEntity<prescription> getPrescriptionById(@PathVariable int id) {
        return prescriptionRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<prescription> updatePrescription(@PathVariable int id, @RequestBody prescription prescription) {
        if (!prescriptionRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        prescription.setRxNumber(id);
        return ResponseEntity.ok(prescriptionRepository.save(prescription));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePrescription(@PathVariable int id) {
        if (!prescriptionRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        prescriptionRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
