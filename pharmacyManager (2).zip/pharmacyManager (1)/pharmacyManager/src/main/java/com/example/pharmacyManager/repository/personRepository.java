package com.example.pharmacyManager.repository;

import com.example.pharmacyManager.entities.person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface personRepository extends JpaRepository<person, Integer> {
    person findByFirstNameAndLastName(String firstName, String lastName);
}
