package com.example.pharmacyManager.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import java.util.Date;

@Entity
public class prescription {
 @Id
    private int rxNumber;
    private String dosage;
    private Date prescriptionWritten;

    @ManyToOne
    private provider provider;

    @ManyToOne
    private patient patient;

    @ManyToOne
    private medication medication;

    public int getRxNumber() {
        return rxNumber;
    }

    public void setRxNumber(int rxNumber) {
        this.rxNumber = rxNumber;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public Date getPrescriptionWritten() {
        return prescriptionWritten;
    }

    public void setPrescriptionWritten(Date prescriptionWritten) {
        this.prescriptionWritten = prescriptionWritten;
    }

    public provider getProvider() {
        return provider;
    }

    public void setProvider(provider provider) {
        this.provider = provider;
    }

    public patient getPatient() {
        return patient;
    }

    public void setPatient(patient patient) {
        this.patient = patient;
    }

    public medication getMedication() {
        return medication;
    }

    public void setMedication(medication medication) {
        this.medication = medication;
    }
}
