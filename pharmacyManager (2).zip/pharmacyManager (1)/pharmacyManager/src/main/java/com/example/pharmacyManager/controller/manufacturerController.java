package com.example.pharmacyManager.controller;

import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*;  
import org.springframework.http.ResponseEntity;
import com.example.pharmacyManager.entities.manufacturer; 


@RestController
@RequestMapping("/api/manufacturers")

public class manufacturerController {
 @Autowired
    private com.example.pharmacyManager.repository.manufacturerRepository manufacturerRepository;

    @GetMapping
    public List<manufacturer> getAllManufacturers() {
        return manufacturerRepository.findAll();
    }

    @PostMapping
    public manufacturer createManufacturer(@RequestBody manufacturer manufacturer) {
        return manufacturerRepository.save(manufacturer);
    }

    @GetMapping("/{id}")
    public ResponseEntity<manufacturer> getManufacturerById(@PathVariable int id) {
        return manufacturerRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<manufacturer> updateManufacturer(@PathVariable int id, @RequestBody manufacturer manufacturer) {
        if (!manufacturerRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        manufacturer.setManufacturerID(id);
        return ResponseEntity.ok(manufacturerRepository.save(manufacturer));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteManufacturer(@PathVariable int id) {
        if (!manufacturerRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        manufacturerRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
