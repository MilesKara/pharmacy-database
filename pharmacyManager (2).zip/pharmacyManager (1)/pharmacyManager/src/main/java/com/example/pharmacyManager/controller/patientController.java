package com.example.pharmacyManager.controller;
import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*;  
import org.springframework.http.ResponseEntity;
import com.example.pharmacyManager.entities.patient; 
@RestController
@RequestMapping("/api/patients")

public class patientController {
    @Autowired
    private com.example.pharmacyManager.repository.patientRepository patientRepository;

    @GetMapping
    public List<patient> getAllPatients() {
        return patientRepository.findAll();
    }

    @PostMapping
    public patient createPatient(@RequestBody patient patient) {
        return patientRepository.save(patient);
    }

    @GetMapping("/{id}")
    public ResponseEntity<patient> getPatientById(@PathVariable int id) {
        return patientRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<patient> updatePatient(@PathVariable int id, @RequestBody patient patient) {
        if (!patientRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        patient.setPersonID(id);
        return ResponseEntity.ok(patientRepository.save(patient));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePatient(@PathVariable int id) {
        if (!patientRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        patientRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
