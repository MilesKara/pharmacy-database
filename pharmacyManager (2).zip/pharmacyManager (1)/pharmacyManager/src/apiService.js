const fetchData = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/your-endpoint');
      const data = await response.json();
      console.log(data);
    } catch (error) {
      console.error('Error:', error);
    }
  };
  
  export default fetchData;