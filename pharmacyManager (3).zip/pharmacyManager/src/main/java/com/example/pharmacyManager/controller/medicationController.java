package com.example.pharmacyManager.controller;

import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*;  
import org.springframework.http.ResponseEntity;
import com.example.pharmacyManager.entities.medication; 
@RestController
@RequestMapping("/api/medications")

public class medicationController {
 @Autowired
    private com.example.pharmacyManager.repository.medicationRepository medicationRepository;

    @GetMapping
    public List<medication> getAllMedications() {
        return medicationRepository.findAll();
    }

    @PostMapping
    public medication createMedication(@RequestBody medication medication) {
        return medicationRepository.save(medication);
    }

    @GetMapping("/{id}")
    public ResponseEntity<medication> getMedicationById(@PathVariable int id) {
        return medicationRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<medication> updateMedication(@PathVariable int id, @RequestBody medication medication) {
        if (!medicationRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        medication.setMedicationID(id);
        return ResponseEntity.ok(medicationRepository.save(medication));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMedication(@PathVariable int id) {
        if (!medicationRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        medicationRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
