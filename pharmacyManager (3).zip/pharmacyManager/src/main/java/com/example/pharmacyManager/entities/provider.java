package com.example.pharmacyManager.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class provider {
    @Id
    private int personID;
    private String licenseNum;
    private String type;

    public int getPersonID() {
        return personID;
    }

    public void setPersonID(int personID) {
        this.personID = personID;
    }

    public String getLicenseNum() {
        return licenseNum;
    }

    public void setLicenseNum(String licenseNum) {
        this.licenseNum = licenseNum;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
