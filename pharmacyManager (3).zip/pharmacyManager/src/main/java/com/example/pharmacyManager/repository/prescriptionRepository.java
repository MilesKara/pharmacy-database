package com.example.pharmacyManager.repository;

import com.example.pharmacyManager.entities.prescription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface prescriptionRepository extends JpaRepository<prescription, Integer> {
    List<prescription> findByPatientId(Integer patientId);
    List<prescription> findByMedicationId(Integer medicationId);
}