package com.example.pharmacyManager.repository;


import com.example.pharmacyManager.entities.provider;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface providerRepository extends JpaRepository<provider, Integer> {
    provider findByLicenseNum(String licenseNum);
}