package com.example.pharmacyManager.controller;
import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*;  
import org.springframework.http.ResponseEntity;
import com.example.pharmacyManager.entities.provider; 
@RestController
@RequestMapping("/api/provider")

public class providerController {
    @Autowired
    private com.example.pharmacyManager.repository.providerRepository providerRepository;

    @GetMapping
    public List<provider> getAllProviders() {
        return providerRepository.findAll();
    }

    @PostMapping
    public provider createProvider(@RequestBody provider provider) {
        return providerRepository.save(provider);
    }

    @GetMapping("/{id}")
    public ResponseEntity<provider> getProviderById(@PathVariable int id) {
        return providerRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<provider> updateProvider(@PathVariable int id, @RequestBody provider provider) {
        if (!providerRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        provider.setPersonID(id);
        return ResponseEntity.ok(providerRepository.save(provider));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProvider(@PathVariable int id) {
        if (!providerRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        providerRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
