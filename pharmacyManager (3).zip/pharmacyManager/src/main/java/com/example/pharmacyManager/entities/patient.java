package com.example.pharmacyManager.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class patient {
    @Id
    private int personID;
    private String insuranceType;
    private String medicationHistory;

    public int getPersonID() {
        return personID;
    }

    public void setPersonID(int personID) {
        this.personID = personID;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public String getMedicationHistory() {
        return medicationHistory;
    }

    public void setMedicationHistory(String medicationHistory) {
        this.medicationHistory = medicationHistory;
    }
}
