package com.example.pharmacyManager.repository;

import com.example.pharmacyManager.entities.manufacturer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface manufacturerRepository extends JpaRepository<manufacturer, Integer> {
    manufacturer findByBrandName(String brandName);
}