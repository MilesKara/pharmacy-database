package com.example.pharmacyManager.repository;

import com.example.pharmacyManager.entities.patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface patientRepository extends JpaRepository<patient, Integer> {
    // You can add custom queries if needed
    patient findByInsuranceType(String insuranceType);
}