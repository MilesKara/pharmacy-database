package com.example.pharmacyManager.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class medication {

    @Id
    private int medicationID;
    private String name;
    private String form;
    private String strength;

    @ManyToOne
    private manufacturer manufacturer;

    public int getMedicationID() {
        return medicationID;
    }

    public void setMedicationID(int medicationID) {
        this.medicationID = medicationID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getForm() {
        return form;
    }

    public void setForm(String form) {
        this.form = form;
    }

    public String getStrength() {
        return strength;
    }

    public void setStrength(String strength) {
        this.strength = strength;
    }

    public manufacturer getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(manufacturer manufacturer) {
        this.manufacturer = manufacturer;
    }
}
